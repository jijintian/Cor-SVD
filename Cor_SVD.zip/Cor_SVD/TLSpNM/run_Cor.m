clc;
clear;
addpath(genpath('./'));
addpath('./');
addpath('./measure');
addpath('..\Datasets');

dataname = ["MSRCv1"];
num_runs = 2; %for each rho
W_types = ["COV_UNCENTERED"]; 

rhos = 0:0.1:1.0; 
num_rhos = length(rhos);

for it_name = 1:length(dataname)
    for i_w = 1:length(W_types)
        W_type = W_types(i_w);
        
        load(strcat('Datasets/', dataname(it_name), '.mat'));
        gt_raw = double(truelabel{1});
        X_raw_data = data; 
        
        [gt_sorted, sort_idx] = sort(gt_raw, 'ascend');
        gt_ideal = gt_sorted; 
        num_views = length(X_raw_data);
        N = length(gt_ideal);
        cls_num = length(unique(gt_ideal));

        total_pool = []; 
      
        trend_mean = zeros(num_rhos, 9); 
        trend_std = zeros(num_rhos, 9);
       
        viz_data = struct();

        %% ==================== (rho  0 to 1) ===================
        for i_rho = 1:num_rhos
            rho = rhos(i_rho);
            current_rho_results = [];
            fprintf('\n[Ratio %.1f] ', rho);

            for r = 1:num_runs         
                fprintf('.'); 
                
                rand_idx = 1:N; 
                num_shuffle = round(N * rho);
                if num_shuffle > 0
                    idx_to_shuffle = randperm(N, num_shuffle);
                    shuffled_vals = idx_to_shuffle(randperm(num_shuffle));
                    rand_idx(idx_to_shuffle) = shuffled_vals;
                end
                
                gt_run = gt_ideal(rand_idx);
                X_run = cell(1, num_views);
                X_for_base = cell(1, num_views); 
                for v = 1:num_views
                    temp_X = X_raw_data{v}(:, sort_idx);
                    X_run{v} = temp_X(:, rand_idx);
                    [X_run{v}] = NormalizeData(X_run{v});
                    X_for_base{v} = X_run{v}'; 
                end
                
                % compute transform basis
                tic;
                [V_base] = compute_V_base(X_for_base, W_type, gt_run);
                base_time = toc;

                max_val_in_run = -1;
                best_re_in_run = [];
                best_Z_in_run = [];
                
                base_lambda = 0.0001; 
                for p = 1:9
                    lambda = base_lambda * p;
                    
                    tic;
                    [Z, E, iter] = TLS_pNMMSC_V(X_run, lambda, V_base);
                    
                    S_sum = 0;
                    for k = 1:num_views
                        S_sum = S_sum + abs(Z{k}) + abs(Z{k}');
                    end
                    C = SpectralClustering(S_sum, cls_num);
                    t_elapsed = toc;
                    result = ClusteringMeasure1(gt_run, C);
                    
                    if result(1) > max_val_in_run
                        max_val_in_run = result(1);
                        best_re_in_run = [result,base_time,t_elapsed];
                        iter_best = iter;
                    end
                end
                
                current_rho_results = [current_rho_results; best_re_in_run];
                total_pool = [total_pool; best_re_in_run]; 
                fprintf('.');
            end
            
            trend_mean(i_rho, :) = mean(current_rho_results, 1);
            trend_std(i_rho, :) = std(current_rho_results, 0, 1);
            fprintf(' Mean ACC: %.4f', trend_mean(i_rho, 1));
        end
        
        Overall_Table_Mean = mean(total_pool, 1);
        Overall_Table_Std = std(total_pool, 0, 1);

        fprintf('\n\n>>> Summary for %s (%s) <<<', dataname(it_name), W_type);
        fprintf('\nOverall Average ACC: %.4f ± %.4f\n', Overall_Table_Mean(1), Overall_Table_Std(1));

        if ~exist('result', 'dir'), mkdir('result'); end
        save_path = fullfile('result', strcat('Result_', W_type, '_', dataname(it_name), '.mat'));
        
        save(save_path, 'rhos', 'trend_mean', 'trend_std', 'Overall_Table_Mean', 'Overall_Table_Std');
    end
end