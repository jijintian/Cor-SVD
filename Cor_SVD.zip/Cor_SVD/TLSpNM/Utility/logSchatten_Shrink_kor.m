function [X] = logSchatten_Shrink_kor(X, lambda, mode,cls)

sX = size(X);

if mode == 3
    n3 = sX(1);
    m = min(sX(2), sX(3));
else
    n3 = sX(3);
    m = min(sX(1), sX(2));
end

if mode == 1
    Y=X2Yi(X,3);
elseif  mode == 3
    Y = shiftdim(X, 1);
else
    Y = X;
end

%% ================= K-means =================
% 1. Prepare the data by reshaping Y to (n1*n2) x n3 before transposition.
n1 = size(Y, 1);
n2 = size(Y, 2);
Z = reshape(Y, [n1 * n2, n3])'; % After transposition, each row is a sample, as required by kmeans.

K = cls;%cls;
[labels, ~] = kmeans(Z, K, 'Distance', 'sqeuclidean', 'Replicates', 3, 'MaxIter', 100);

% 3. Generate permutation indices idx.
% Sort by cluster label: samples in cluster 1 first, then cluster 2, and so on.
[~, idx] = sort(labels); 

% f = squeeze(mean(mean(Y,1),2));   % 1 × N
% [~, idx] = sort(f);
% 
% % 4. Apply the permutation along the third dimension of Y.
Y = Y(:, :, idx);
%% =================================================================================
%% =================================================================================

Yhat = fft(Y,[],3);
if mod(n3,2) == 0
    endValue = n3/2;
    for i = 1:endValue
        [uhat,shat,vhat] = svd(full(Yhat(:,:,i)),'econ');
        for j = 1:m
            shat(j,j) = update_log(shat(j,j),lambda); %% update_log(y,beta): solve min_{x>=0} beta*log(1+x)+1/2*(x-y)^2
        end
        Yhat(:,:,i) = uhat*shat*vhat';
        if i > 1 
            Yhat(:,:,n3-i+2) = conj(uhat)*shat*conj(vhat)';
        end
    end
    [uhat,shat,vhat] = svd(full(Yhat(:,:,endValue+1)),'econ');
    for j = 1:m
        shat(j,j) = update_log(shat(j,j),lambda);
    end
    Yhat(:,:,endValue+1) = uhat*shat*vhat';
else
    endValue = (n3+1)/2;
    for i = 1:endValue
        [uhat,shat,vhat] = svd(full(Yhat(:,:,i)),'econ');
        for j = 1:m
            shat(j,j) = update_log(shat(j,j),lambda);
        end
        Yhat(:,:,i) = uhat*shat*vhat';
        if i > 1 
            Yhat(:,:,n3-i+2) = conj(uhat)*shat*conj(vhat)';
        end
    end
end

%% Raw IFFT
Y = ifft(Yhat,[],3);

%% ================= Inverse permutation: restore the original sample order =================
% Restore processed data to its original positions to preserve input-output alignment.
Y_restored = zeros(size(Y));
Y_restored(:, :, idx) = Y; % Apply the inverse mapping using the stored permutation indices.
Y = Y_restored;
%% ==========================================================================

if mode == 1
    X = Yi2X(Y,3);
elseif mode == 3
    X = shiftdim(Y, 2);
else
    X = Y;
end