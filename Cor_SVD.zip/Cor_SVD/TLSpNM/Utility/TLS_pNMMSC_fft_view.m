function [Z,E,iter] = TLS_pNMMSC_fft_view(X,lambda)
%% Parameter settings
N = size(X{1}, 2);
K = length(X); % number of views

% Default
maxIter = 200;
epsilon = 1e-7;
mu = 1e-5;
eta = 2;
max_mu = 1e10; 


%% Initialize...
for k=1:K
    Z{k} = zeros(N,N); 
    W{k} = zeros(N,N);
    G{k} = zeros(N,N);
    E{k} = zeros(size(X{k},1),N); 
    Y{k} = zeros(size(X{k},1),N);   
end

G_tensor = cat(3, G{:,:});
iter = 0;
Isconverg = 0;

%% Iterating
while(Isconverg == 0)  
    %-------------------Update Z^k-------------------------------  
    for k=1:K
%         tmp = X{k}'*(Y{k} + mu*X{k} - mu*E{k})/mu - W{k}/mu + G{k};
%         Z{k}=(X{k}'*X{k}+eye(N,N))\tmp;
        %% economic updating rule for Z^k
        tmp = X{k}'*(Y{k} + mu*X{k} - mu*E{k})/mu - W{k}/mu + G{k};
        tmp1 = (X{k}*X{k}'+eye(size(X{k},1),size(X{k},1)))\(X{k}*tmp);
        Z{k} = tmp-X{k}'*tmp1;
    end
    
    %-------------------Update E^k-------------------------------  
    for k=1:K
        tmp = X{k}-X{k}*Z{k}+Y{k}/mu;
        E{k} = solve_l1l2(tmp,lambda/mu);
    end
    
      
    %-------------------Update G---------------------------------
    Z_tensor = cat(3, Z{:,:});
    W_tensor = cat(3, W{:,:});
    G_tensor = logSchatten_Shrink(Z_tensor + W_tensor/mu, 1/mu, 2); 
     %-------------------Update auxiliary variable---------------
     W_tensor = W_tensor  + mu*(Z_tensor - G_tensor);
    for k=1:K
        Y{k} = Y{k} + mu*(X{k}-X{k}*Z{k}-E{k});
        G{k} = G_tensor(:,:,k);
        W{k} = W_tensor(:,:,k);
    end   
    
     % Coverge condition
    Isconverg = 1;
    for k=1:K
        if (norm(X{k}-X{k}*Z{k}-E{k},inf)>epsilon)
            history.norm_Z = norm(X{k}-X{k}*Z{k}-E{k},inf);
            Isconverg = 0;
        end

        if (norm(Z{k}-G{k},inf)>epsilon)
            history.norm_Z_G = norm(Z{k}-G{k},inf);
            Isconverg = 0;
        end 
    end
    
    if (iter>maxIter)
        Isconverg  = 1;
    end
    
    % Update penalty params
    mu = min(mu*eta, max_mu);
    iter = iter + 1;
end
          
