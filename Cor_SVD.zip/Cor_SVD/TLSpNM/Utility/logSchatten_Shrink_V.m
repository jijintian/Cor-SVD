function [X] = logSchatten_Shrink_V(X, lambda, mode, V_base)


sX = size(X);

if mode == 3
    n3 = sX(1);
    m = min(sX(2), sX(3));
else
    n3 = sX(3);
    m = min(sX(1), sX(2));
end


if mode == 1
   Y=X2Yi(X,3);
elseif  mode == 3
   Y = shiftdim(X, 1);
else
   Y = X;
end


Yhat = tensor_prod_dim3(Y, V_base'); 

[d1, d2, d3] = size(Yhat);
lambda = lambda/d3;
ratio = 1; 
k_cutoff = ceil(d3 * ratio);
weights = linspace(1, 1, k_cutoff); 

for i = 1:d3
    if i <= k_cutoff

        [uhat, shat, vhat] = svd(full(Yhat(:,:,i)), 'econ');
        diag_s = diag(shat);
        
        curr_lambda = lambda * weights(i);
        for j = 1:length(diag_s)
            diag_s(j) = update_log(diag_s(j), curr_lambda);
        end
        Yhat(:,:,i) = uhat * diag(diag_s) * vhat';
    else
        Yhat(:,:,i) = 0; 
    end
end

Y = tensor_prod_dim3(Yhat, V_base);
if mode == 1
    X = Yi2X(Y,3);
elseif mode == 3
    X = shiftdim(Y, 2);
else
    X = Y;
end
end

function [Out] = tensor_prod_dim3(T, Mat)
    [d1, d2, d3] = size(T);
    m = size(Mat, 1);
    T_reshaped = reshape(T, d1*d2, d3);
    Out_reshaped = T_reshaped * Mat.'; 
    Out = reshape(Out_reshaped, d1, d2, m);
end