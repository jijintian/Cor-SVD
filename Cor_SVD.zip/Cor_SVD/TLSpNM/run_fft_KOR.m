clc;
clear;
addpath('./');
addpath('./measure');
addpath('..\Datasets');

dataname = ["MSRCv1"];

num_runs = 10; %for each rho
rhos = 0:0.1:1.0; 
num_rhos = length(rhos);


for it_name = 1:length(dataname)
 
    load(strcat('Datasets/', dataname(it_name), '.mat'));
    
    gt_raw = double(truelabel{1});
    X_raw_data = data; 
    

    [gt_sorted, sort_idx] = sort(gt_raw, 'ascend');
    gt_ideal = gt_sorted; 
    num_views = length(X_raw_data);
    N = length(gt_ideal);
    cls_num = length(unique(gt_ideal));

 
    total_pool = []; 

    trend_mean = zeros(num_rhos, 8); 
    trend_std = zeros(num_rhos, 8);

    viz_data = struct();

    %% ==================== (rho  0 to 1) ===================
    for i_rho = 1:num_rhos
        rho = rhos(i_rho);
        current_rho_results = [];
        fprintf('\n[Ratio %.1f] ', rho);

        for run = 1:num_runs
            rand_idx = 1:N; 
            num_shuffle = round(N * rho);
            if num_shuffle > 0
                idx_to_shuffle = randperm(N, num_shuffle);
                shuffled_vals = idx_to_shuffle(randperm(num_shuffle));
                rand_idx(idx_to_shuffle) = shuffled_vals;
            end
            
            gt_run = gt_ideal(rand_idx);
            X_run = cell(1, num_views);
            for v = 1:num_views
                temp_X = X_raw_data{v}(:, sort_idx); 
                X_run{v} = temp_X(:, rand_idx);    
                [X_run{v}] = NormalizeData(X_run{v});
            end

            max_acc_this_run = -1;
            best_res_this_run = [];
            best_Z_this_run = []; 

            lambda_base = 0.0001;
            for i = 1:9
                current_lambda = lambda_base * i;
                
                tic;
                [Z, E,iter] = TLS_pNMMSC_KOR(X_run, current_lambda,cls_num);

                S_consensus = 0;
                for k = 1:num_views
                    S_consensus = S_consensus + abs(Z{k}) + abs(Z{k}');
                end
                
                C = SpectralClustering(S_consensus, cls_num);
                t_elapsed = toc;
                
                res = ClusteringMeasure1(gt_run, C);
                
                if res(1) > max_acc_this_run
                    max_acc_this_run = res(1);
                    best_res_this_run = [res,t_elapsed];
                    last_iter = iter;
                end
            end
            
            current_rho_results = [current_rho_results; best_res_this_run];
            total_pool = [total_pool; best_res_this_run]; 
            fprintf('.');
        end
        trend_mean(i_rho, :) = mean(current_rho_results, 1);
        trend_std(i_rho, :) = std(current_rho_results, 0, 1);
        fprintf(' Mean ACC: %.4f', trend_mean(i_rho, 1));
    end

    Overall_Table_Mean = mean(total_pool, 1);
    Overall_Table_Std = std(total_pool, 0, 1);

    fprintf('\n\n>>> Summary for %s <<<', dataname(it_name));
    fprintf('\nOverall Average ACC: %.4f ± %.4f\n', Overall_Table_Mean(1), Overall_Table_Std(1));

    if ~exist('result', 'dir'), mkdir('result'); end
    save_filename = fullfile('result', strcat('Result_fft_KOR_', dataname(it_name), '.mat'));
    
    save(save_filename, 'rhos', 'trend_mean', 'trend_std', 'Overall_Table_Mean', 'Overall_Table_Std');
end