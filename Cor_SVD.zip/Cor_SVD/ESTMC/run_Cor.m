clear; clc;
folder_now = pwd;
addpath(genpath(fullfile(folder_now, 'funs')));
addpath(genpath(fullfile(folder_now, 'Utility')));
addpath('..\Datasets');


dataname = ["MSRCv1"];
num_runs = 10; %for each rho
rhos = 0:0.1:1.0; 
num_rhos = length(rhos);
W_types = ["COV"]; 

for it_name = 1:length(dataname)
    for i_type = 1:length(W_types)
        W_type = W_types(i_type);
        
        fprintf('\n======================================================\n');
        fprintf('Processing: %s | Method: T-SVD (%s)\n', dataname(it_name), W_type);
        fprintf('======================================================\n');
        
        % 1. Ideal Baseline
        load(strcat('Datasets/', dataname(it_name), '.mat'));
        gt_raw = truelabel{1}; X_raw_cells = data'; nV = length(X_raw_cells);
        [gt_sorted, sort_idx] = sort(gt_raw, 'ascend');
        gt_ideal = gt_sorted; 
        for v = 1:nV, X_raw_cells{v} = X_raw_cells{v}(:, sort_idx); end
        nN = length(gt_ideal); cls_num = length(unique(gt_ideal));

        total_pool = []; 
        trend_mean = zeros(num_rhos, 9); 
        trend_std = zeros(num_rhos, 9);
        viz_data = struct();

        %% ==================== Loop over Shuffle Ratios ===================
        for i_rho = 1:num_rhos
            rho = rhos(i_rho);
            current_rho_results = [];
            fprintf('\n[Ratio %.1f] ', rho);

            for run = 1:num_runs
                rand_idx = 1:nN;
                num_shuffle = round(nN * rho);
                if num_shuffle > 0
                    idx_to_shuffle = randperm(nN, num_shuffle);
                    rand_idx(idx_to_shuffle) = idx_to_shuffle(randperm(num_shuffle));
                end
                
                gt_run = gt_ideal(rand_idx);
                X = cell(1, nV);
                X_for_base = cell(1, nV);
                for v = 1:nV
                    X{v} = X_raw_cells{v}(:, rand_idx);
                    [X{v}] = NormalizeData(X{v});
                    X_for_base{v} = X{v}'; 
                end
                
      
                tic;
                [V_base] = compute_V_base(X_for_base, W_type, gt_run);
                base_time = toc;
                
                max_acc = -1; best_res = []; best_Z = [];
                anchor_list = [cls_num, 2*cls_num, 3*cls_num];
                
                for i_lam = -6:1:0
                    for i_del = -2:1:0
                        lam = 10^i_lam; del = 10^i_del;
                        
                        tic;
                        [y,  Z_res,~, ~, ~, ~, ~] = ESTMC_V(X, cls_num, del, lam, cls_num, 4, V_base);
                        al_time=toc;
                        res = ClusteringMeasure(gt_run, y);
                 
                        if res(1) > max_acc
                            max_acc = res(1); 
                            best_res = [res,al_time,base_time];

                        end
                    end
                end
                
                current_rho_results = [current_rho_results; best_res];
                total_pool = [total_pool; best_res]; 
                
          fprintf('.');
            end
            
            trend_mean(i_rho, :) = mean(current_rho_results, 1);
            trend_std(i_rho, :) = std(current_rho_results, 0, 1);
            fprintf(' Mean ACC: %.4f\n', trend_mean(i_rho, 1));
        end

        Overall_Table_Mean = mean(total_pool, 1);
        Overall_Table_Std = std(total_pool, 0, 1);

        fprintf('\n\n>>> Summary for %s (%s) <<<\n', dataname(it_name), W_type);
        fprintf('Overall Average ACC: %.4f ± %.4f\n', Overall_Table_Mean(1), Overall_Table_Std(1));

        if ~exist('result', 'dir'), mkdir('result'); end
        file_name = ['Result_', char(W_type), '_', char(dataname(it_name)), '.mat'];
        save_path = fullfile('.', 'result', file_name);
        
        save(save_path, 'rhos', 'trend_mean', 'trend_std', 'Overall_Table_Mean', 'Overall_Table_Std');
    end
end
