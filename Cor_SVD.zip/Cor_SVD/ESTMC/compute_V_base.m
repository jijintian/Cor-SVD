function [V_base] = compute_V_base(X_raw, W_type, Y, Ind)
%COMPUTE_V_BASE Build the transform basis used by ESTMC_V.
%   X_raw: cell array, each cell is N x d_v (samples in rows)
%   W_type: 'GFT', 'Cov', 'Cov_centered', 'Attention', 'Ideal'
%   Y: labels, only required by 'Ideal' and 'GMC'
%   Ind: optional N x V observation indicator for incomplete views

if nargin < 3
    Y = [];
end

nV = length(X_raw);
num_samples = size(X_raw{1}, 1);

if nargin < 4
    Ind = ones(num_samples, nV);
    for v = 1:nV
        row_norms = sum(abs(X_raw{v}), 2);
        Ind(:, v) = (row_norms > 1e-6);
    end
end

Co_occur = Ind * Ind';
Co_occur(Co_occur == 0) = 1;

K_sum = zeros(num_samples, num_samples);
for v = 1:nV
    temp_X = X_raw{v};
    valid_idx = (Ind(:, v) == 1);

    % Original initialization: row-wise L2 normalization only.
    row_norm = sqrt(sum(temp_X(valid_idx, :).^2, 2));
    temp_X(valid_idx, :) = temp_X(valid_idx, :) ./ (row_norm + eps);
    temp_X(~valid_idx, :) = 0;
    K_sum = K_sum + (temp_X * temp_X');
end

K_unbiased = K_sum ./ Co_occur;
K_unbiased = (K_unbiased + K_unbiased') / 2;


switch upper(char(W_type))
    case 'GFT'
        k_diag = diag(K_unbiased);
        Dist_sq = repmat(k_diag, 1, num_samples) + repmat(k_diag', num_samples, 1) - 2 * K_unbiased;
        Dist_sq = max(Dist_sq, 0);
        Dist_sq = Dist_sq - diag(diag(Dist_sq));
        
        k_knn = min(10, max(num_samples - 1, 1));
        sigma = mean(sqrt(Dist_sq(:)));
        if sigma < eps
            sigma = 1;
        end
        
        W_V = zeros(num_samples, num_samples);
        for i = 1:num_samples
            [~, sorted_idx] = sort(Dist_sq(i, :), 'ascend');
            neighbors = sorted_idx(2:k_knn+1);
            W_V(i, neighbors) = exp(-Dist_sq(i, neighbors) / (2 * sigma^2 + eps));
        end
        W_V = (W_V + W_V') / 2;
        
        d = sum(W_V, 2);
        D_inv_sqrt = diag(1 ./ sqrt(d + eps));
        L = eye(num_samples) - D_inv_sqrt * W_V * D_inv_sqrt;
        L = (L + L') / 2;
        [V_all, D_val] = eig(full(L));
        [~, ind] = sort(diag(D_val), 'ascend');
        V_base = V_all(:, ind);
        
    case 'IDEAL'
        if isempty(Y)
            error('compute_V_base:MissingLabels', 'Labels Y are required when W_type is Ideal.');
        end
        W_I = double(repmat(Y(:), 1, num_samples) == repmat(Y(:)', num_samples, 1));
        W_I = W_I - eye(num_samples);
        d = sum(W_I, 2);
        D_inv_sqrt = diag(1 ./ sqrt(d + eps));
        L_ideal = eye(num_samples) - D_inv_sqrt * W_I * D_inv_sqrt;
        [V_all, D_val] = eig(full(L_ideal));
        [~, ind] = sort(diag(D_val), 'ascend');
        V_base = V_all(:, ind);
             
    case {'COV', 'COV_UNCENTERED'}
        % Original cosine-Gram covariance basis.
        [V_all, D_val] = eig(full(K_unbiased));
        [~, ind] = sort(diag(D_val), 'descend');
        V_base = V_all(:, ind);

    case 'COV_CENTERED'
        % Optional centered correlation basis. The mean of each view is
        % estimated from observed samples only; other basis types retain
        % the original initialization above.
        K_centered_sum = zeros(num_samples, num_samples);
        for v = 1:nV
            temp_X = X_raw{v};
            valid_idx = (Ind(:, v) == 1);

            if any(valid_idx)
                observed_mean = mean(temp_X(valid_idx, :), 1);
                temp_X(valid_idx, :) = temp_X(valid_idx, :) - observed_mean;
                row_norm = sqrt(sum(temp_X(valid_idx, :).^2, 2));
                temp_X(valid_idx, :) = temp_X(valid_idx, :) ./ (row_norm + eps);
            end

            temp_X(~valid_idx, :) = 0;
            K_centered_sum = K_centered_sum + temp_X * temp_X';
        end

        K_centered = K_centered_sum ./ Co_occur;
        K_centered = (K_centered + K_centered') / 2;
        [V_all, D_val] = eig(full(K_centered));
        [~, ind] = sort(diag(D_val), 'descend');
        V_base = V_all(:, ind);
    case 'RANDOM'
        % Random orthogonal basis
        G = randn(num_samples, num_samples);
        [V_base, R] = qr(G, 0);
        
        % Canonicalize column signs of the QR decomposition
        sign_diag = sign(diag(R));
        sign_diag(sign_diag == 0) = 1;
        V_base = V_base * diag(sign_diag);
        
        eig_value = ones(num_samples, 1);
        
    case 'ATTENTION'
        Scores = K_unbiased * 5;
        max_score = max(Scores, [], 2);
        Scores_exp = exp(Scores - max_score);
        Scores_exp(Co_occur == 1 & K_sum == 0) = 0;
        A_attn = Scores_exp ./ (sum(Scores_exp, 2) + eps);
        A_attn = (A_attn + A_attn') / 2;
        [V_all, D_val] = eig(full(A_attn));
        [~, ind] = sort(diag(D_val), 'descend');
        V_base = V_all(:, ind);
        
    otherwise
        error('compute_V_base:UnsupportedType', ...
            ['Unsupported W_type "%s". Supported types: GFT, Cov, ' ...
             'Cov_centered, Attention, Ideal, Random.'], ...
            char(W_type));
end

end
