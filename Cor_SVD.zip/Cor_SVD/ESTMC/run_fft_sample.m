clear; clc;
folder_now = pwd;
addpath(genpath(fullfile(folder_now, 'funs')));
addpath(genpath(fullfile(folder_now, 'Utility')));
addpath('..\Datasets');

dataname = ["MSRCv1"];
num_runs = 10; %for each rho
rhos = 0:0.1:1.0; 
num_rhos = length(rhos);

for it_name = 1:length(dataname)
    fprintf('\n>>> Processing: %s <<<\n', dataname(it_name));
    
    load(strcat('Datasets/', dataname(it_name), '.mat'));
    gt_raw = truelabel{1}; X_raw_cells = data'; nV = length(X_raw_cells);
    [gt_sorted, sort_idx] = sort(gt_raw, 'ascend');
    gt_ideal = gt_sorted; 
    for v = 1:nV, X_raw_cells{v} = X_raw_cells{v}(:, sort_idx); end
    nN = length(gt_ideal); cls_num = length(unique(gt_ideal));


    total_results_pool = []; 

    trend_mean = zeros(num_rhos, 8); trend_std = zeros(num_rhos, 8);

    viz_data = struct();

    for i_rho = 1:num_rhos
        rho = rhos(i_rho);
        current_rho_results = [];
        fprintf('Ratio %.1f: ', rho);

        for run = 1:num_runs

            rand_idx = 1:nN;
            num_shuffle = round(nN * rho);
            if num_shuffle > 0
                idx_to_shuffle = randperm(nN, num_shuffle);
                rand_idx(idx_to_shuffle) = idx_to_shuffle(randperm(num_shuffle));
            end
            
            gt_run = gt_ideal(rand_idx);
            X = cell(1, nV);
            for v = 1:nV
                X{v} = X_raw_cells{v}(:, rand_idx);
                [X{v}] = NormalizeData(X{v});
            end
            

            max_acc = -1; best_res = []; best_Z = [];
            for i_lam = -6:1:0
                for i_del = -2:1:0
                    lam = 10^i_lam; del = 10^i_del;
                    tic;
                    [y, Z_consensus, ~, ~, ~, ~, ~] = ESTMC(X, cls_num, del, lam, cls_num, 4);
                    al_time = toc;
                    res = ClusteringMeasure(gt_run, y);
                    if res(1) > max_acc
                        max_acc = res(1); 
                        best_res = [res,al_time]; 
                    end
                end
            end
            
            current_rho_results = [current_rho_results; best_res];
            total_results_pool = [total_results_pool; best_res];
            
fprintf('.');
        end
        
        trend_mean(i_rho, :) = mean(current_rho_results, 1);
        trend_std(i_rho, :) = std(current_rho_results, 0, 1);
         fprintf(' Mean ACC: %.4f', trend_mean(i_rho, 1));
    end

    Table_Mean = mean(total_results_pool, 1);
    Table_Std = std(total_results_pool, 0, 1);


    if ~exist('result', 'dir'), mkdir('result'); end
    save_path = fullfile('.', 'result', ['Result_fft_sample_', char(dataname(it_name)), '.mat']);
    save(save_path, 'trend_mean', 'trend_std', 'Table_Mean', 'Table_Std');
end