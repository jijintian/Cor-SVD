function [res_cluster,time] = evaluatePerformance(beta, gamma, lambda, alpha_1, alpha_2)
 
% addpath('./Caltech101-Datasets')
addpath('./Utility')
load Caltech101-all
%% Nonlinear anchor feature embedding: RBF mapping
V = size(X,2);
load Anchor_Caltech101
%fprintf('Nonlinear Anchor Embedding...\n');
for it = 1:V
%fprintf('The %d-th view Nonlinear Anchor Embeeding...\n',it);
    dist = EuDist2(X{it},Anchor{it},0); % Compute squared Euclidean distances between X and Anchor (bSqrt = 0).
    sigma = mean(min(dist,[],2).^0.5)*2;% Set sigma to twice the mean square root of the row-wise minimum distances.
    feaVec = exp(-dist/(2*sigma*sigma));% Apply the Gaussian RBF to the distance matrix.
    X{it} = bsxfun(@minus, feaVec', mean(feaVec',2));% Center each row of feaVec' by subtracting its mean.
end
clear feaVec dist sigma dist Anchor it


%% ----------------------Initialize parameters------------------------
MaxIter = 10;       % 5 iterations are okay, but better results for 10
innerMax = 10;      % Maximum number of inner iterations
K = 128;            % Hashing code length



N = size(X{1},2);%sample number

N = size(X{1},2);
% Initialize B_bar.
rand('seed',100);
sel_sample = X{4}(:,randsample(N, 1000),:);
[pcaW, ~] = eigs(cov(sel_sample'), K);  % Compute the leading K eigenvectors of the covariance matrix of sel_sample'.
B_bar = sign(pcaW'*X{4});                   % Binarize pcaW' * X{4} using sign().

% Initialize B.
for v =1:V
    rand('seed',100);
    sel_sample = X{v}(:,randsample(N, 1000),:);
    [pcaW, ~] = eigs(cov(sel_sample'), K);  % Compute the leading K eigenvectors of the covariance matrix of sel_sample'.
    B{v}= sign(pcaW'*X{v});          % Binarize pcaW' * X{v} using sign().
end

% Initialize the Lambda_1 matrices.
Lambda_1 = cell(1, V);
for v =1:V
    Lambda_1{v}= zeros(K, N);          % Initialize the multiplier matrix to zero.
end
% Initialize P_tensor by stacking the updated B matrices into a tensor.
B_tensor = cat(3, B{:,:});
P_tensor = B_tensor;
% Lambda_2 is a tensor.
Lambda_2_tensor = zeros(K, N, V);  
dim1 = K;dim2 = N;dim3 = V;
sX = [K, N, V];
        
C = numel(unique(Y));           % Number of clusters

% Initialize D and G.
rand('seed',500);
D = B_bar(:,randsample(N, C));
HamDist = 0.5*(K - B_bar'*D);
[~,ind] = min(HamDist,[],2);
G = sparse(ind,1:N,1,C,N,N);
G = full(G);
DG = C*G;

%% Variables after initialization
%  A  % Matrices: A, X, B; tensors: none; scalar: alpha_1; matrices: E, F, H
%  B  % Matrices: B_bar, Lambda_1; tensors: Lambda_2, P_tensor; scalars: alpha_2, beta, lambda
%B_bar% Matrices: none; tensor: B__tensor; scalar: gamma
% DG  % Matrices: D, G; tensors: none; scalar: gamma




clear HamDist ind initInd n_randm pcaW sel_sample view
%% ----------------------End Initialization------------------------


tic;
%disp('----------The proposed method (multi-view)----------');
for iter = 1:MaxIter
    %fprintf('The %d-th iteration...\n',iter);
     %% Update A_v---------------------------------------------------------
     %svd_EFH 
        for v = 1:V
            M{v} = X{v} * Lambda_1{v}' + alpha_1 * X{v} * B{v}';
            [E{v}, F{v}, H{v}] = svd(M{v});
            A{v} = H{v} * E{v}(:,1:K)';
        end

    %% Update B_v---------------------------------------------------------
        for v= 1:V
            numerator = beta * B_bar - Lambda_1{v} + alpha_1 * A{v} * X{v} + (Lambda_2_tensor(:, :, v) + alpha_2* P_tensor(:, :, v));% Note: an inverse transform is involved here.
            denominator = beta + alpha_1 + alpha_2 - 2 * lambda;
            B{v} = sign(numerator ./ denominator);
            B{v}(B{v}==0) = -1;
        end
           
    %% Update P-----------------------------------------------------------
        B_tensor = cat(3, B{:,:});
        b = B_tensor(:);
        l = Lambda_2_tensor(:);
        [p, objV] = wshrinkObj_weight(b + 1/alpha_2*l,alpha_2,sX,0,3);
        P_tensor = reshape(p, sX);

        history.objval(iter+1) = objV;


    %% Update B_bar------------------------------------------------------------
        % Initialize the accumulator for the sum of B matrices.
        BX = zeros(size(B{1}));
        for v = 1:V
            BX = BX + B{v};
        end
        B_bar = (BX + gamma * D * G)  / (beta * V + gamma);



    %% Update D and G-------------------------------------------------------
       for iterInner = 1:innerMax
            % For simplicity, directly using DPLM here
            D = sign(B_bar*G'); 
            D(D==0) = 1;    % Replace zero outputs of sign() with 1.
            theta = .001; tau = .01; % Preferred for this dataset
                for iterIn = 1:3
                    grad = -B_bar*G' + theta*repmat(sum(D),K,1);  % Gradient
                    D = sign(D-1/tau*grad); D(D==0) = 1; 
                end
              HamDist = 0.5*(K - B_bar'*D); % Hamming distance between binary codes and cluster centers; see "Supervised Hashing with Kernels".
              [~,indx] = min(HamDist,[],2);% indx(i) is the column index of the minimum value in row i.
              G = sparse(indx,1:N,1,C,N,N);
        end
        DG = D*G;

    % clear iterIn grad HamDist indx tau theta
    %% Update Lambda_1 Lambda_2------------------------------------------------------------
        for v= 1:V
         Lambda_1{v} = Lambda_1{v} + alpha_1 *(B{v} - A{v} * X{v});
        end     
        Lambda_2_tensor = Lambda_2_tensor + alpha_2 * (P_tensor - B_tensor);
end

elapsed_time = toc;
%disp('----------Main Iteration Completed----------');

[~,pred_label] = max(G,[],1);
res_cluster = ClusteringMeasure(Y, pred_label);
time_char = num2str(elapsed_time);
time = str2double(time_char);

end
