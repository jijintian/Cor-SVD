function paretoSet = findParetoFront(data)
    % data: Each row is a solution, and each column is an objective.
    % paretoSet: Logical vector marking the Pareto-optimal rows.

    numSolutions = size(data, 1);
    paretoSet = true(numSolutions, 1);  % Initially assume all solutions are Pareto optimal.

    for i = 1:numSolutions
        if paretoSet(i)  % Check only solutions still considered Pareto optimal.
            for j = 1:numSolutions
                if i ~= j && all(data(j, :) <= data(i, :)) && any(data(j, :) < data(i, :))
                    paretoSet(i) = false;  % A better solution was found, so solution i is not Pareto optimal.
                    break;
                end
            end
        end
    end
end

