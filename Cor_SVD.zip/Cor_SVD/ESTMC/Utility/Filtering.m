%Filtering
load('results.mat');

[bestACC, bestIdx] = max(results(:, 6));
bestParameters_ACC = results(bestIdx, :);

[bestNMI, bestIdx] = max(results(:, 7));
bestParameters_NMI = results(bestIdx, :);

[bestPurity, bestIdx] = max(results(:, 8));
bestParameters_Purity = results(bestIdx, :);

[bestTime, bestIdx] = min(results(:, 9));
bestParameters_Time = results(bestIdx, :);


figure;
plot(results(:, 6));
title('ACC under different parameter combinations');
xlabel('Parameter Combination Index');
ylabel('ACC');

figure;
plot(results(:, 7));
title('NMI under different parameter combinations');
xlabel('Parameter Combination Index');
ylabel('NMI');

figure;
plot(results(:, 8));
title('Purity under different parameter combinations');
xlabel('Parameter Combination Index');
ylabel('Purity');

figure;
plot(results(:, 9));
title('Time under different parameter combinations');
xlabel('Parameter Combination Index');
ylabel('Time');



% For example, assign equal weights to all metrics.
weights = [0.25, 0.25, 0.25, 0.25];  % ACC, NMI, Purity, Time

% Normalize runtime, assuming shorter runtimes are better.
normalized_time = (max(results(:, 9)) - results(:, 9)) / (max(results(:, 9)) - min(results(:, 9)));

% Compute the total score.
scores = weights(1)*results(:, 6) + weights(2)*results(:, 7) + weights(3)*results(:, 8) + weights(4)*normalized_time;

% Find the highest score.
[bestScore, bestIdx] = max(scores);
bestParameters = results(bestIdx, :);


paretoSet = findParetoFront([results(:, 6:8), -results(:, 9)]);  % Negate runtime because shorter runtimes are better.
paretoResults = results(paretoSet, :);


% Display the best parameter combination for each metric.
fprintf('Best Parameters for ACC: Beta = %.5f, Gamma = %.5f, Lambda = %.5f, Alpha_1 = %.5f, Alpha_2 = %.5f, ACC = %.5f, NMI = %.5f, Purity = %.5f, Time = %.5f\n', bestParameters_ACC);
fprintf('Best Parameters for NMI: Beta = %.5f, Gamma = %.5f, Lambda = %.5f, Alpha_1 = %.5f, Alpha_2 = %.5f, ACC = %.5f, NMI = %.5f, Purity = %.5f, Time = %.5f\n', bestParameters_NMI);
fprintf('Best Parameters for Purity: Beta = %.5f, Gamma = %.5f, Lambda = %.5f, Alpha_1 = %.5f, Alpha_2 = %.5f, ACC = %.5f, NMI = %.5f, Purity = %.5f, Time = %.5f\n', bestParameters_Purity);
fprintf('Best Parameters for Time: Beta = %.5f, Gamma = %.5f, Lambda = %.5f, Alpha_1 = %.5f, Alpha_2 = %.5f, ACC = %.5f, NMI = %.5f, Purity = %.5f, Time = %.5f\n', bestParameters_Time);

% Display the best parameter combination according to the weighted score.
fprintf('Best Parameters with Weighted Score: Beta = %.5f, Gamma = %.5f, Lambda = %.5f, Alpha_1 = %.5f, Alpha_2 = %.5f, ACC = %.5f, NMI = %.5f, Purity = %.5f, Time = %.5f\n', bestParameters);

% Display the Pareto-optimal solutions.
for i = 1:size(paretoResults, 1)
    fprintf('Pareto Solution %d: Beta = %.5f, Gamma = %.5f, Lambda = %.5f, Alpha_1 = %.5f, Alpha_2 = %.5f, ACC = %.5f, NMI = %.5f, Purity = %.5f, Time = %.5f\n', i, paretoResults(i, :));
end



% Load the data.
load('results.mat');

% Retrieve the parameters in row 924.
params_924 = results(924, :);

% Display the parameters in row 924.
fprintf('Parameters on row 924: Beta = %.6f, Gamma = %.6f, Lambda = %.6f, Alpha_1 = %.6f, Alpha_2 = %.6f, ACC = %.6f, NMI = %.6f, Purity = %.6f, Time = %.6f\n', params_924);


