function [G,objV] = solve_G_fun_V(x,miu,sX,yita,fun,V_base)

% solve min 1/miu ||G||_gamma+1/2||G-(Z+W/MIU)||_F^2

% Rotate the tensor to size N x V x N.
er = 0.0001;
G_hat=reshape(x,sX);
objV = 0;
G_hat_re = shiftdim(G_hat, 1);


Yhat = tensor_prod_dim3(G_hat_re, V_base'); 

max_iter = 100;

[d1, d2, d3] = size(Yhat);
%miu=miu*d3;
ratio = 1; 
k_cutoff = ceil(d3 * ratio);
weights = linspace(1, 1, k_cutoff);

for i = 1:d3
    if i <= k_cutoff
        
    [uhat,shat,vhat] = svd(full(Yhat(:,:,i)),'econ');
    sigma = diag(shat);
    sigma_i = sigma;
    for j = 1: max_iter
        w_i = rank_fun_derivative(sigma_i,yita,fun);
        sigma_i1 = max(0,sigma - w_i/miu);
        if sum((sigma_i1-sigma_i).^2) < er
            break
        end
        sigma_i = sigma_i1;
    end
    shat = diag(sigma_i1);
    objV = objV + sum(shat(:));
     Yhat(:,:,i) = uhat*shat*vhat';

    else
        Yhat(:,:,i) = 0; 
    end
end

% --- 4. Apply the IGFT ---
Y_rec = tensor_prod_dim3(Yhat, V_base);

G = shiftdim(Y_rec, 2);
end

function [Out] = tensor_prod_dim3(T, Mat)
    [d1, d2, d3] = size(T);
    m = size(Mat, 1);
    T_reshaped = reshape(T, d1*d2, d3);
    Out_reshaped = T_reshaped * Mat.'; 
    Out = reshape(Out_reshaped, d1, d2, m);
end
