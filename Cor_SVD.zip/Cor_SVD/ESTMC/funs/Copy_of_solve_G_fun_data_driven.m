function [G, objV] = solve_G_fun_data_driven(x, miu, sX, yita,fun)
% solve min 1/miu ||G||_gamma + 1/2||G-(Z+W/MIU)||_F^2
% Replace the FFT with a data-driven unitary transform.

er = 0.0001;
    G_hat = reshape(x, sX);
    
    % 1. Rearrange dimensions so that mode 3 is the sample dimension.
    % Assume G_hat originally has dimensions d x v x n.
    % Does shiftdim(G_hat, 1) change the dimensions to v x n x d?
    % Verify that the third dimension of G_hat_re is the intended sample dimension.
    G_hat_re = shiftdim(G_hat, 1);
    
    [n1, n2, n3] = size(G_hat_re); % n3 is the number of samples.
    
    %% 2. Learn the transform matrix U (data-driven step).
    % Unfold the tensor into a matrix of size n3 x (n1*n2).
    Unfolding = reshape(permute(G_hat_re, [3, 1, 2]), n3, []); 
    
    % SVD: U may have size n3 x n3 or n3 x (n1*n2).
    [U, ~, ~] = svd(Unfolding, 'econ');
    

   
    % Get the transform dimension K: K = n3 for square U, and K < n3 otherwise.
    transform_dim = size(U, 2); 
    
    %% 3. Forward transform
    % (K x n3) * (n3 x M) -> K x M
    G_transformed_mat = U' * Unfolding;
    
    % Use the dynamically determined transform_dim instead of n3.
    % Reshape: K, n1, n2
    G_hat_trans = permute(reshape(G_transformed_mat, transform_dim, n1, n2), [2, 3, 1]);
    % G_hat_trans now has size n1 x n2 x transform_dim.
    
    %% 4. Solve each slice in the transform domain.
    G_hat_processed = zeros(size(G_hat_trans));
    objV = 0;
    max_iter = 100;

    % Iterate over transform_dim, which may equal n3 or be smaller.
    for i = 1:transform_dim
        slice = G_hat_trans(:,:,i);
        
        [uhat, shat, vhat] = svd(slice, 'econ');
        sigma = diag(shat);
        sigma_i = sigma;
        
        % Solve by iterative thresholding.
        for j = 1:max_iter
            w_i = rank_fun_derivative(sigma_i,yita,fun);
            sigma_i1 = max(0, sigma - w_i/miu);
            
            if sum((sigma_i1 - sigma_i).^2) < er
                break
            end
            sigma_i = sigma_i1;
        end
        
        shat_new = diag(sigma_i1);
        objV = objV + sum(shat_new(:));
        G_hat_processed(:,:,i) = uhat * shat_new * vhat';
    end

    %% 5. Inverse transform
    % First unfold into a matrix of size K x (n1*n2).
    Unfolding_processed = reshape(permute(G_hat_processed, [3, 1, 2]), transform_dim, []);
    
    % Multiply by U: (n3 x K) * (K x M) -> n3 x M.
    % This restores the dimension from transform_dim to n3.
    G_recon_mat = U * Unfolding_processed;
    
    % Restore the tensor shape: n3 x n1 x n2 -> permute -> n1 x n2 x n3.
    G_recon = permute(reshape(G_recon_mat, n3, n1, n2), [2, 3, 1]);
    
    %% 6. Restore the original input dimension order.
    G = shiftdim(G_recon, 2);
end
