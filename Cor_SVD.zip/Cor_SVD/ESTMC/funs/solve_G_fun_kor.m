function [G,objV] = solve_G_fun_kor(x,miu,sX,yita,fun,cls_num)
% solve min 1/miu ||G||_gamma+1/2||G-(Z+W/MIU)||_F^2
% Reorder samples using k-means pseudo-labels.

er = 0.0001;
G_hat = reshape(x,sX);
objV = 0;
G_hat_re = shiftdim(G_hat, 1); % Rearrange dimensions.
n3 = size(G_hat_re, 3);

%% ================= Reordering by k-means clustering =================
% 1. Prepare clustering features by flattening each slice into a feature vector.
n1 = size(G_hat_re, 1);
n2 = size(G_hat_re, 2);
Z_feat = reshape(G_hat_re, [n1 * n2, n3])'; 

% 2. Run k-means clustering (use K = 10 by default, or adjust it based on n3).
K = cls_num+1;%min(10, n3); 
%rng(0); % Fix the random seed for reproducibility.
[labels, ~] = kmeans(Z_feat, K, 'Distance', 'sqeuclidean', 'MaxIter', 100, 'Replicates', 3);

% 3. Generate permutation indices from the cluster labels.
[~, idx] = sort(labels); 
G_hat_re = G_hat_re(:, :, idx); % Apply the permutation.
%% ========================================================

G_hat_fft = fft(G_hat_re,[],3);
max_iter = 100;
G_hat_ff = zeros(size(G_hat_fft)); % Preallocate memory.

% Check whether n3 is even.
if mod(n3, 2) == 0
    endValue = n3/2 + 1;
    for i = 1:endValue
        [uhat,shat,vhat] = svd(full(G_hat_fft(:,:,i)),'econ');
        sigma = diag(shat);
        sigma_i = sigma;
        for j = 1: max_iter
            w_i = rank_fun_derivative(sigma_i,yita,fun);
            sigma_i1 = max(0,sigma - w_i/miu);
            if sum((sigma_i1-sigma_i).^2) < er
                break
            end
            sigma_i = sigma_i1;
        end
        shat = diag(sigma_i1);
        objV = objV + sum(shat(:));
        G_hat_ff(:,:,i) = uhat*shat*vhat';
        if i > 1 && i < endValue
            G_hat_ff(:,:,n3-i+2) = conj(uhat)*shat*conj(vhat)';
            objV = objV + sum(shat(:));
        end
    end
    
    % Process the Nyquist-frequency slice (n3/2 + 1) when n3 is even.
    [uhat,shat,vhat] = svd(full(G_hat_fft(:,:,endValue)),'econ');
    sigma = diag(shat);
    sigma_i = sigma;
    for j = 1: max_iter
        w_i = rank_fun_derivative(sigma_i,yita,fun);
        sigma_i1 = max(0,sigma - w_i/miu);
        if sum((sigma_i1-sigma_i).^2) < er
            break
        end
        sigma_i = sigma_i1;
    end
    shat = diag(sigma_i1);
    objV = objV + sum(shat(:));
    G_hat_ff(:,:,endValue) = uhat*shat*vhat';
    
else
    % n3 is odd.
    endValue = (n3+1)/2;
    for i = 1:endValue
        [uhat,shat,vhat] = svd(full(G_hat_fft(:,:,i)),'econ');
        sigma = diag(shat);
        sigma_i = sigma;
        for j = 1: max_iter
            w_i = rank_fun_derivative(sigma_i,yita,fun);
            sigma_i1 = max(0,sigma - w_i/miu);
            if sum((sigma_i1-sigma_i).^2) < er
                break
            end
            sigma_i = sigma_i1;
        end
        shat = diag(sigma_i1);
        objV = objV + sum(shat(:));
        G_hat_ff(:,:,i) = uhat*shat*vhat';
        if i > 1
            G_hat_ff(:,:,n3-i+2) = conj(uhat)*shat*conj(vhat)';
            objV = objV + sum(shat(:));
        end
    end
end

G_temp = ifft(G_hat_ff,[],3);

%% ================= Inverse permutation: restore the original order =================
G_restored = zeros(size(G_temp));
G_restored(:, :, idx) = G_temp; % Put the reordered results back in their original positions.
G_temp = G_restored;
%% ========================================================

G = shiftdim(G_temp, 2);
end